# Assistant Pro – Backend

Ce dossier contient le backend Node.js (Express) pour Assistant Pro.

## Démarrage en local

```bash
npm install
npm start
```

Le serveur écoute sur le port défini dans la variable d'environnement `PORT` (3000 par défaut).
